<?php
return array (
  '网站广告管理' => '?s=Admin-Ads-Show',
  '影片数据管理' => '?s=Admin-Vod-Show',
);
?>