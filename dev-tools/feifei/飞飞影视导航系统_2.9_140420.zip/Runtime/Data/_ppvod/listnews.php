<?php
return array (
  0 => 
  array (
    'list_id' => '23',
    'list_pid' => '0',
    'list_oid' => '23',
    'list_sid' => '2',
    'list_name' => '新闻资讯',
    'list_skin' => 'pp_newslist',
    'list_skin_detail' => 'pp_vod',
    'list_skin_play' => 'pp_play',
    'list_skin_type' => 'pp_vodtype',
    'list_dir' => 'xinwenzixun',
    'list_status' => '1',
    'list_keywords' => '',
    'list_title' => '',
    'list_description' => '',
    'list_jumpurl' => '',
  ),
);
?>