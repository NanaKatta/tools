<?php
return array (
  0 => 
  array (
    'link_id' => '1',
    'link_name' => '飞飞影视导航系统',
    'link_logo' => 'http://',
    'link_url' => 'http://www.feifeicms.com',
    'link_order' => '1',
    'link_type' => '1',
  ),
);
?>