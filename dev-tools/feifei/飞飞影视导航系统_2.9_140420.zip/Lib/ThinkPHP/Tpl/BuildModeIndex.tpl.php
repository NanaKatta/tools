<?php
// 可视化简约布署模式
class IndexAction extends Action
{
    public function index()
    {
        header("Content-Type:text/html; charset=utf-8");
        echo "引导式布署模式，流程待添加";
    }
}
?>