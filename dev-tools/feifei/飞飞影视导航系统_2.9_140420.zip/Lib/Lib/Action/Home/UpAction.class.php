<?php
class UpAction extends HomeAction{
 				
}
?>